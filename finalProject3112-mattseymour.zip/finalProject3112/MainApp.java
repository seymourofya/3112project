package finalProject3112;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AddressBook addressBook = new AddressBook();

        while (true) {

            System.out.println("------------------");
            System.out.println("\n1. Add Contact");
            System.out.println("2. Edit Contact");
            System.out.println("3. Delete Contact");
            System.out.println("4. Display Contacts");
            System.out.println("5. Save Contacts to File");
            System.out.println("6. Load Contacts from File");
            System.out.println("7. Exit");
            System.out.println("Enter your choice: ");
            System.out.println("------------------");

            int choice = scanner.nextInt();
            scanner.nextLine(); 
            switch (choice) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter phone number: ");
                    String phoneNumber = scanner.nextLine();
                    System.out.print("Enter email: ");
                    String email = scanner.nextLine();

                    Contact newContact = new Contact(name, phoneNumber, email);
                    addressBook.addContact(newContact);
                    System.out.println("Contact added.");
                    break;

                case 2:
                    System.out.print("Enter the index of the saved contact (starting from 0): ");
                    int editIndex = scanner.nextInt();
                    scanner.nextLine();

                    System.out.print("Enter new name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new phone number: ");
                    String newPhoneNumber = scanner.nextLine();
                    System.out.print("Enter new email: ");
                    String newEmail = scanner.nextLine();

                    Contact editedContact = new Contact(newName, newPhoneNumber, newEmail);
                    addressBook.editContact(editIndex, editedContact);
                    System.out.println("Contact edited.");
                    break;

                case 3:
                    System.out.print("Enter the index of the contact to delete (starting from 0): ");
                    int deleteIndex = scanner.nextInt();
                    addressBook.deleteContact(deleteIndex);
                    System.out.println("Contact deleted.");
                    break;

                case 4:
                    System.out.println("List of Contacts:");
                    addressBook.displayContacts();
                    break;

                case 5:
                    System.out.print("Enter the name of the file you would like to save the Contacts to: ");
                    String saveFileName = scanner.nextLine();
                    addressBook.saveContactsToFile(saveFileName);
                    break;

                case 6:
                    System.out.print("Enter the name of the file you would like to load Contacts from: ");
                    String loadFileName = scanner.nextLine();
                    addressBook.loadContactsFromFile(loadFileName);
                    break;

                case 7:
                    System.out.println("Now exiting the address book app. Have a good day!");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Choice not valid. Please enter a valid input");
            }
        }
    }
}